"""
生成不同类型的任务，先生成，再按时间排序，给id赋值
"""
import math
import os
from utils import add_date
import random
from datetime import datetime as dt, timedelta, time


class Task:
    def __init__(self, tid, task_type, complexity, quality_threshold, location, num_area, start_time, end_time,
                 budget, remain_budget, sensing_time, sensing_rounds, interval):
        self.id = tid
        self.task_type = task_type
        self.complexity = complexity
        self.quality_threshold = quality_threshold
        self.location = location
        self.num_area = num_area
        self.start_time = start_time
        self.end_time = end_time
        self.budget = budget
        self.remain_budget = remain_budget
        self.sensing_time = sensing_time
        self.sensing_rounds = sensing_rounds
        self.interval = interval

        self.assigned_workers = []

    def is_to_assign(self, current_time):
        if add_date(self.start_time) <= current_time < add_date(self.end_time):
            if self.task_type in ['TypeA', 'TypeB']:
                if self.sensing_rounds == len(self.assigned_workers):
                    return False
                else:
                    return True
            else:
                if len(self.assigned_workers) < self.num_area:
                    return True
                else:
                    return False
        else:
            return False

    def to_dict(self):
        return {
            'id': self.id,
            'task_type': self.task_type,
            'complexity': self.complexity,
            'quality_threshold': self.quality_threshold,
            'location': self.location,
            'num_area': self.num_area,
            'start_time': self.start_time.strftime('%H:%M:%S'),
            'end_time': self.end_time.strftime('%H:%M:%S'),
            'budget': self.budget,
            'remain_budget': self.remain_budget,
            'sensing_time': self.sensing_time,
            'sensing_rounds': self.sensing_rounds,
            'interval': self.interval,
            'assigned_workers': self.assigned_workers
        }

    @classmethod
    def from_dict(cls, task_dict):
        def parse_time(t_str):
            return dt.strptime(t_str, '%H:%M:%S').time()

        start_time = parse_time(task_dict.get('start_time'))
        end_time = parse_time(task_dict.get('end_time'))
        num_area = task_dict.get('num_area', 0)
        task = cls(
            task_dict.get('id'),
            task_dict.get('task_type'),
            task_dict.get('complexity'),
            task_dict.get('quality_threshold'),
            task_dict.get('location'),
            num_area,
            start_time,
            end_time,
            task_dict.get('budget'),
            task_dict.get('remain_budget'),
            task_dict.get('sensing_time'),
            task_dict.get('sensing_rounds'),
            task_dict.get('interval')
        )
        task.assigned_workers = task_dict.get('assigned_workers', [])
        return task


frequent_locations_file = "/data/t_drive/t_drive_final/frequent_locations.txt"
# 读取热点区域的坐标
with open(frequent_locations_file, "r") as f:
    locations = [line.strip() for line in f.readlines()]


# 定义给坐标添加浮动的函数
def add_floating_point(coord, precision=5):
    # 获取前两位小数
    integer_part = int(coord)  # 获取整数部分
    decimal_part = coord - integer_part  # 获取小数部分

    # 保留前两位小数
    rounded_decimal = round(decimal_part, 2)

    # 生成后三位小数的随机部分，范围为0.00000到0.00999
    floating_value = random.uniform(0, 0.00999)

    # 最终结果：前两位小数 + 随机生成的后三位小数，并控制小数点后五位
    result = round(integer_part + rounded_decimal + floating_value, precision)

    return result


# 最小经度: 115.6, 最大经度: 118.2
# 最小纬度: 39.0, 最大纬度: 42.3
def location_mode(mode='uniform'):
    location = (0, 0)  # 初始化坐标为 (0, 0)

    if mode == 'uniform':  # 均匀分布
        # 生成随机经纬坐标，保留五位小数
        longitude = round(random.uniform(115.6, 118.2), 5)
        latitude = round(random.uniform(39.0, 42.3), 5)
        location = (longitude, latitude)

    elif mode == 'concentrated':  # 集中分布
        # 随机选择一个热点区域
        selected_location = random.choice(locations)
        # 提取经纬度
        longitude, latitude = map(float, selected_location.strip("()").split(","))
        # 给经纬度添加浮动
        new_longitude = add_floating_point(longitude)
        new_latitude = add_floating_point(latitude)
        location = (new_longitude, new_latitude)

    elif mode == 'mixed':  # 混合式分布
        if random.random() < 0.5:  # 50%概率均匀分布
            # 生成随机经纬坐标，保留五位小数
            longitude = round(random.uniform(115.6, 118.2), 5)
            latitude = round(random.uniform(39.0, 42.3), 5)
            location = (longitude, latitude)
        else:  # 50%概率集中分布
            # 随机选择一个热点区域
            selected_location = random.choice(locations)
            # 提取经纬度
            longitude, latitude = map(float, selected_location.strip("()").split(","))
            # 给经纬度添加浮动
            new_longitude = add_floating_point(longitude)
            new_latitude = add_floating_point(latitude)
            location = (new_longitude, new_latitude)

    return location


def generate_continuous_positions(start_location, x_extent, y_extent):
    positions = []
    lat, lon = start_location

    # 纬度每公里增量（固定值）
    delta_lat = 1 / 111  # 纬度每度大约对应 111 公里

    for i in range(x_extent):
        for j in range(y_extent):
            # 计算新的纬度
            new_lat = round(lat + j * delta_lat, 5)

            # 计算新的经度（考虑纬度对经度增量的影响）
            delta_lon = 1 / (111 * math.cos(math.radians(new_lat)))  # 经度每公里增量
            new_lon = round(lon + i * delta_lon, 5)

            positions.append((new_lat, new_lon))
    return positions


def generate_tasks(num_tasks, mode, type_ratios):
    task_types = list(type_ratios.keys())
    tasks = []

    for i in range(num_tasks):
        task_type = random.choices(task_types, weights=type_ratios.values())[0]  # 随机选择一个任务类型（有权重）
        # complexity = random.choice([1, 2, 3])
        # quality_threshold = 0.6 + 0.1 * (complexity - 1)
        complexity, quality_threshold = 0, 0
        location = [0, 0]
        num_area = 1
        start_time, end_time = time(0, 0, 0), time(21, 0, 0)
        budget, sensing_rounds, sensing_time, interval = 0, 0, 0, 0

        if task_type == 'TypeA':  # 简单周期性多轮次任务
            location = location_mode(mode)
            complexity = random.choice([1, 2])
            quality_threshold = 0.6 + 0.1 * (complexity - 1)
            sensing_rounds = random.randint(4, 6)
            sensing_time = 5 * complexity
            interval = 0.5 * random.choice([1.5, 2])  # 45min/1h
            duration = sensing_rounds * interval
            latest_start_hour = int(20 - duration)
            start_hour = random.randint(8, latest_start_hour - 1) if latest_start_hour > 8 else 8
            start_time = time(start_hour, 0, 0)
            # 将 start_time 转换为 datetime 对象
            start_datetime = dt.combine(dt.today(), start_time)
            # 计算结束时间
            end_datetime = start_datetime + timedelta(hours=duration)
            if end_datetime > dt.combine(dt.today(), time(20, 0, 0)):
                end_time = time(20, 0, 0)
            else:
                end_time = end_datetime.time()
            budget = (20 + sensing_time) * sensing_rounds

        elif task_type == 'TypeB':  # 实时性多轮次任务
            location = location_mode(mode)
            complexity = random.choice([1, 2, 3])
            quality_threshold = 0.6 + 0.1 * (complexity - 1)
            sensing_rounds = random.randint(1, 4)
            sensing_time = 5 * complexity
            interval = 0.5 * random.choice([1.5, 2])  # 45min/1h
            duration = sensing_rounds * interval
            latest_start_hour = int(20 - duration)
            start_hour = random.randint(8, latest_start_hour - 1) if latest_start_hour > 8 else 8
            start_time = time(start_hour, 0, 0)
            # 将 start_time 转换为 datetime 对象
            start_datetime = dt.combine(dt.today(), start_time)
            # 计算结束时间
            end_datetime = start_datetime + timedelta(hours=duration)
            if end_datetime > dt.combine(dt.today(), time(20, 0, 0)):
                end_time = time(20, 0, 0)
            else:
                end_time = end_datetime.time()
            budget = (20 + sensing_time) * sensing_rounds

        elif task_type == 'TypeC':  # 非实时性数据采集任务
            complexity = random.choice([1, 2, 3])
            quality_threshold = 0.6 + 0.1 * (complexity - 1) + 0.05
            location0 = location_mode(mode)
            x_extent = random.choice([1, 2, 3])  # 随机选择 x 延伸范围
            y_extent = random.choice([1, 2, 3])  # 随机选择 y 延伸范围
            num_area = x_extent * y_extent
            location = generate_continuous_positions(location0, x_extent, y_extent)
            sensing_time = 10 * complexity
            start_time = time(random.randint(8, 17), 0, 0)
            duration = random.randint(4, 6)
            end_time = add_date(start_time) + timedelta(hours=duration)
            if end_time > dt.combine(dt.today(), time(20, 0, 0)):
                end_time = time(20, 0, 0)
            budget = (40 + sensing_time) * num_area

        elif task_type == 'TypeD':  # 实时数据采集任务
            complexity = random.choice([1, 2, 3])
            quality_threshold = 0.6 + 0.1 * (complexity - 1) + 0.05
            location0 = location_mode(mode)
            x_extent = random.choice([1, 2])  # 随机选择 x 延伸范围
            y_extent = random.choice([1, 2])  # 随机选择 y 延伸范围
            num_area = x_extent * y_extent
            location = generate_continuous_positions(location0, x_extent, y_extent)
            sensing_time = 10 * complexity
            duration = random.randint(2, 4)  # 1/2/3h
            start_time = time(random.randint(8, 18), random.randint(0, 59), random.randint(0, 59))
            # 将 start_time 转换为 datetime 对象
            start_datetime = dt.combine(dt.today(), start_time)
            # 计算结束时间
            end_datetime = start_datetime + timedelta(hours=duration)
            if end_datetime > dt.combine(dt.today(), time(20, 0, 0)):
                end_time = time(20, 0, 0)
            else:
                end_time = end_datetime.time()
            budget = (40 + sensing_time) * num_area
        remain_budget = budget

        task = Task(i + 1, task_type, complexity, quality_threshold, location, num_area, start_time, end_time, budget,
                    remain_budget, sensing_time, sensing_rounds, interval)
        tasks.append(task)

    return tasks


# # 生成任务示例
# num_tasks = 5
# mode = 'concentrated'
# type_ratios = {'TypeA': 0.3, 'TypeB': 0.2, 'TypeC': 0.4, 'TypeD': 0.1}
# tasks = generate_tasks(num_tasks, mode, type_ratios)
#
# for task in tasks:
#     print(task.__dict__)
