'''
生成工人，考虑信誉度
'''
import os
import random
from datetime import datetime as dt, timedelta
from collections import defaultdict  # 添加这一行
import numpy as np
import pandas as pd

from utils import add_date, manhattan_distance


class Worker:
    def __init__(self, wid, location, speed, start_time, end_time, reputation, skill_level, proficiency,
                 unit_sensing_bid, is_malicious, trajectory_file):
        self.id = wid
        self.location = location
        self.speed = speed
        self.start_time = start_time
        self.end_time = end_time
        self.reputation = reputation
        self.skill_level = skill_level
        self.proficiency = proficiency
        self.unit_sensing_bid = unit_sensing_bid
        self.is_malicious = is_malicious
        self.trajectory_file = trajectory_file  # 轨迹文件

        self.last_task_location = None
        self.assigned_tasks = []

    # 判断工人是否可用：1.在工作时间；2.在当前时间后十分钟之内有空
    def is_available(self, current_time):
        if add_date(self.start_time) <= current_time < add_date(self.end_time):
            if not self.last_task_location:
                return True
            else:
                last_task = self.assigned_tasks[-1]
                return last_task['expected_finish_time'] <= current_time + timedelta(minutes=10)
        else:
            return False

    def to_dict(self):
        return {
            'id': self.id,
            'location': self.location,
            'speed': self.speed,
            'start_time': self.start_time.strftime('%H:%M:%S'),
            'end_time': self.end_time.strftime('%H:%M:%S'),
            'reputation': self.reputation,
            'skill_level': self.skill_level,
            'proficiency': self.proficiency,
            'unit_sensing_bid': self.unit_sensing_bid,
            'is_malicious': self.is_malicious,
            'trajectory_file': self.trajectory_file,
            'last_task_location': self.last_task_location,
            'assigned_tasks': self.assigned_tasks
        }

    @classmethod
    def from_dict(cls, worker_dict):
        def parse_time(t_str):
            return dt.strptime(t_str, '%H:%M:%S').time()

        start_time = parse_time(worker_dict['start_time'])
        end_time = parse_time(worker_dict['end_time'])
        worker = cls(
            worker_dict['id'],
            worker_dict['location'],
            worker_dict['speed'],
            start_time,
            end_time,
            worker_dict['reputation'],
            worker_dict['skill_level'],
            worker_dict['proficiency'],
            worker_dict['unit_sensing_bid'],
            worker_dict['is_malicious'],
            worker_dict['trajectory_file']
        )
        worker.last_task_location = worker_dict.get('last_task_location', None)
        worker.assigned_tasks = worker_dict.get('assigned_tasks', [])
        return worker


def extract_trajectory_data(trajectory_file):
    # 读取轨迹文件
    df = pd.read_csv(trajectory_file, header=None, names=["vehicle_id", "timestamp", "longitude", "latitude"])

    # 将时间戳列转换为datetime格式
    df["timestamp"] = pd.to_datetime(df["timestamp"])

    # 提取开始时间和结束时间
    start_time = df["timestamp"].iloc[0]  # 第一行时间戳
    end_time = df["timestamp"].iloc[-1]  # 最后一行时间戳

    # 将时间戳转换为时间类型
    start_time = start_time.time()  # 获取时间部分
    end_time = end_time.time()  # 获取时间部分

    # 按小时分组计算速度
    hourly_speeds = defaultdict(list)

    # 遍历相邻轨迹点
    for i in range(1, len(df)):
        # 相邻点坐标
        point_prev = (df["longitude"].iloc[i - 1], df["latitude"].iloc[i - 1])
        point_curr = (df["longitude"].iloc[i], df["latitude"].iloc[i])

        # 计算曼哈顿距离（单位：公里）
        distance = manhattan_distance(point_prev, point_curr)

        # 计算时间差（单位：小时）
        time_diff = (df["timestamp"].iloc[i] - df["timestamp"].iloc[i - 1]).total_seconds() / 3600

        # 避免除零错误以及没有进行移动的点
        if time_diff <= 0 or distance == 0:
            continue

        # 计算瞬时速度（单位：km/h），并保留两位小数
        speed = round(distance / time_diff, 2)

        # 初步过滤明显异常速度（如 >120 km/h）
        if speed > 120:
            continue

        # 获取当前点所属的小时组（基于前一个点的时间）
        hour_group = df["timestamp"].iloc[i - 1].hour
        hourly_speeds[hour_group].append(speed)

    # 对每小时速度进行去噪并计算平均
    valid_avg_speeds = []

    for hour, speeds in hourly_speeds.items():
        if len(speeds) < 2:  # 数据点太少不进行统计
            continue

        # 使用IQR方法排除异常值
        speeds_array = np.array(speeds)
        q1 = np.percentile(speeds_array, 25)
        q3 = np.percentile(speeds_array, 75)
        iqr = q3 - q1

        # 定义合理速度范围
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        valid_speeds = speeds_array[(speeds_array >= lower_bound) & (speeds_array <= upper_bound)]

        # 计算该小时有效平均速度，并保留两位小数
        if len(valid_speeds) > 0:
            valid_avg_speeds.append(round(np.mean(valid_speeds), 2))

    # 计算整体平均速度（加权平均）
    if len(valid_avg_speeds) == 0:
        overall_avg_speed = 0
    else:
        overall_avg_speed = round(np.mean(valid_avg_speeds), 2)

    # 提取第一行的经纬度作为初始位置
    initial_location = (df["longitude"].iloc[0], df["latitude"].iloc[0])

    return start_time, end_time, overall_avg_speed, initial_location


data_dir = "/data/t_drive/t_drive_final"


def generate_workers(num_workers):
    workers = []
    is_malicious = random.random() < 0.15   # 恶意用户的比例设置为 15%，生成一个在 [0.0, 1.0) 范围内的随机浮点数
    task_type_list = ['TypeA', 'TypeB', 'TypeC', 'TypeD']  # 获取所有的轨迹文件名
    trajectory_files = [f for f in os.listdir(data_dir) if f.endswith('.txt')]
    random.shuffle(trajectory_files)  # 打乱轨迹文件的顺序

    for i in range(num_workers):
        # 为工人分配轨迹文件
        trajectory_file = trajectory_files[i % len(trajectory_files)]  # 循环分配文件，确保每个工人都有文件
        final_trajectory_file = os.path.join(data_dir, trajectory_file)

        # 从轨迹文件中提取数据
        start_time, end_time, speed, initial_location = extract_trajectory_data(final_trajectory_file)
        location = initial_location  # 使用轨迹文件的第一个位置作为工人初始位置

        prob = random.random()      # 15%的新用户
        if prob < 0.15:
            reputation = 0.5
        elif is_malicious:  # 恶意用户，通过历史数据已知
            reputation = round(random.uniform(0.3, 0.5), 2)
        else:   # 非恶意用户
            reputation = round(np.clip(np.random.normal(0.7, 0.1), 0.5, 0.95), 2)

        if reputation == 0.5:
            skill_level = 0.5
        else:
            skill_level = round(np.clip(np.random.normal(0.7, 0.1), 0.5, 1.0), 2)

        proficiency = {}
        for task_type in task_type_list:
            if reputation == 0.5:
                task_proficiency = 0.5
            else:
                task_proficiency = round(np.clip(np.random.normal(0.7, 0.15), 0.5, 1.0), 2)
            proficiency[task_type] = task_proficiency

        # 生成高斯扰动并保留3位小数
        X = round(np.clip(np.random.normal(0, 0.2), -0.2, 0.5), 3)

        # 计算 unit_sensing_bid 并保留3位小数
        unit_sensing_bid = round(1 + (skill_level - 0.4) / 0.6 + X, 3)

        worker = Worker(i + 1, location, speed, start_time, end_time, reputation, skill_level,
                        proficiency, unit_sensing_bid, is_malicious, final_trajectory_file)
        workers.append(worker)

    return workers


# num_workers = 5
# workers = generate_workers(num_workers)
#
# for worker in workers:
#     print(worker.__dict__)
